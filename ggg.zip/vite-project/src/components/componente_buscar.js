import { getReport, updateReport, getMimeTypeFromFilename, fileToBase64} from './cliente_backend'

export const componente_buscar = {
  searchCredential: '',
  newUpdateText: '',
  isSearching: false,
  isUpdating: false,
  updateMessage: {
    text: '',
    type: ''
  },
  reportFound: false,
  updated: false,
  reportDetails: {evidences:[]},
  newfiles: {evidences:[]},
  filesLoaded: false,
  searchMessage: { text: '', type: '' },


  async sendUpdate()
  {
    if (!this.newUpdateText.trim()) {
      this.updateMessage = {
        text: "El texto de actualización no puede estar vacío.",
        type: "error"
      };
      return;
    }

    this.isUpdating = true;
    this.updateMessage = { text: '', type: '' };

    const res = await updateReport(this.searchCredential.trim(), this.newUpdateText.trim(), this.newfiles);

    this.isUpdating = false;
    this.updateMessage = {
      type: res.mensaje ? 'success' : 'error'
    };

    console.log(res.mensaje);
    if (res.mensaje)
    {
      alert("PAGINA DICE: "+res.mensaje);
      this.newUpdateText = '';
      this.reportFound = false;
      // O podrías recargar los detalles del reporte aquí si tienes función de búsqueda
    }
  },
  async searchReport()
  {
    this.searchMessage.text = '';
    this.isSearching = true;
    this.updated = false;

    try
    {
        const data = await getReport(`${this.searchCredential}`);

        // Obtener evidencias
        const evidencias = data.evidencias;
        
        this.reportDetails.id = this.searchCredential;
        this.reportDetails.status = data.estado_reporte || 'Desconocido';
        this.reportDetails.type = data.tipo_abuso || 'No especificado';
        this.reportDetails.description = data.descripcion || 'No proporcionada';
        this.reportDetails.location = data.organizacion || 'No especificada';
        
        // Procesar evidencias
        let mimeType;
        for(let i = 0; i < evidencias.length; i++)
        {
          mimeType = evidencias[i]?.filename ? getMimeTypeFromFilename(evidencias[i].filename) : null;
          this.reportDetails.evidences[i].content = evidencias[i]?.content
              ? `data:${mimeType};base64,${evidencias[i].content}`
              : null;
  
          this.reportDetails.evidences[i].evidenceName = evidencias[i].filename || null;
        }


        // Si `actualizaciones` aún no viene, puedes inicializar vacío
        this.reportDetails.updates = data.actualizaciones || [];


        this.reportFound = true;
        this.searchMessage = {
            text: 'Reporte encontrado con éxito.',
            type: 'success'
        };

    }
    catch (error)
    {
        console.error("Error al buscar reporte:", error);
        this.reportFound = false;
        this.searchMessage = {
            text: 'No se pudo encontrar el reporte. Verifica tu credencial.',
            type: 'error'
        };
    }
    finally
    {
        this.isSearching = false;
    }
  },
  async handleFileChange(event)
  {
    const files_array = event.target.files;

    if (files_array && files_array.length > 0)
    {
        const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];

        for (let i = 0; i < files_array.length; i++)
        {
            const file = files_array[i];

            if (!allowedTypes.includes(file.type))
            {
                continue;
            }

            const base64 = await fileToBase64(file);

            this.newfiles.push({
                filename: file.name,
                content: base64,
                index: i
            });
        }

        this.filesLoaded = this.newfiles.length > 0;
    }
    else
    {
        this.filesLoaded = false;
    }  
  },
  eliminarArchivo(index)
  {
      this.newfiles.splice(index, 1);
      // Si quieres actualizar alguna otra variable asociada
      this.filesLoaded = this.newfiles.length > 0;

  },
};